package com.example.student_dashboard_

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
